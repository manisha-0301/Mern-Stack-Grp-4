const mongoose = require('mongoose');

exports.dbConn = ()=>{
    const dbURL = "mongodb+srv://iamaks:sikeO181431@cluster0.ap5kh.mongodb.net/?retryWrites=true&w=majority"
    mongoose.connect(dbURL,{useNewUrlParser:true,useUnifiedTopology:true}).then((result)=>{
    console.log("Database Connected");
    }).catch((err)=>console.log(err));
} 
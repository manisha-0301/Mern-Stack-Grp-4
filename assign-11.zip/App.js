//import './App.css';
import { useState } from 'react';
import Course_Form from './components/course_form/Course_Form';
import {product} from './components/Product/product'

function App() {
  const [courses,setCourse]= useState([
    {
      productName:"Dairy Milk Chocolates",
        productImage:'https://www.chocokick.com/images/detailed/6/71dGEc6n2ML._SL1500_.jpg',
        productPrice:'Rs.154',
        product_created_by:'Cadbury'
    },
    {
      productName:"KitKat Bars",
        productImage:'https://i5.walmartimages.ca/images/Enlarge/218/696/999999-59800218696.jpg',
        productPrice:'Rs.99',
        product_created_by:'Nestle'
    },
    {
      productName:"Hershey Dark Chocolates",
        productImage:'https://i5.walmartimages.com/asr/dbf1232b-8d3f-455d-bb10-4a7a2b6f3b57_1.1ec6120cf7fe7962cfeaa1adf08ff614.jpeg',
        productPrice:'Rs.150',
        product_created_by:'Hershey'
    }
  ]);

  const addnewCourseHandler=(course)=>{
    console.log('add course');
    console.log(course);
    const courseObj = {
      course_name:course.courseName,
      course_price:course.coursePrice,
      course_image:course.courseImage,
      course_conducted_by:course.courseConductedBy
    }
    setCourse([...courses,courseObj]);
  }
  return(
    <div className='App'>
      <Course_Form onCourseAdded ={addnewCourseHandler}/>
      <h1>list course</h1>
      {courses.map((product,index)=>
        <product key ={index} productName={product.productName} productPrice={product.productPrice} productImage={product.productImage} product_created_by={product.product_created_by}/>
      )
      }
    </div>
  )
}

export default App;

  //return (
    // <div className='App' style={{backgroundColor:"#88483e"}}>
    //   <h1 style={{color:"white", fontSize:"30px"}}>CHOCOLATE PRODUCTS</h1>
    //   {
    //     productArr.map((item,index)=>
    //     <Product productName={item.productName} productPrice={item.productPrice} productImage={item.productImage} product_created_by={item.product_created_by}/>
    //     )
      /* <Product productName={productArr[0].productName} productPrice={productArr[0].productPrice} productImage={productArr[0].productImage} product_created_by={productArr[0].product_created_by}/>
      <Product productName={productArr[1].productName} productPrice={productArr[1].productPrice} productImage={productArr[1].productImage} product_created_by={productArr[1].product_created_by}/>
      <Product productName={productArr[2].productName} productPrice={productArr[2].productPrice} productImage={productArr[2].productImage} product_created_by={productArr[2].product_created_by}/> */
      //}
    //</div>
    
  //);
//}

import React,{useState} from "react";
import'./Course_Form.css';
const CourseForm = (props) =>{
    
    const[formInput,setFormInput] = useState({
        courseName:'',
        coursePrice:'',
        courseImage:'',
        courseCounductedBy:''
    })
    const courseNameHandler = (event)=>{
        setFormInput((prevState)=>{
            return{
                ...prevState,
                courseName:event.target.value
            }
        })
    }
    const coursePriceHandler =(event) =>{
        setFormInput({
            ...formInput,
            coursePrice:event.target.value
        });
    }
    const courseImageHandler =(event) =>{
        setFormInput({
            ...formInput,
            courseImage:event.target.value
        });
    }
    const courseConductedByHandler =(event) =>{
        setFormInput({
            ...formInput,
            courseConductedBy:event.target.value
        });
    }
    const formSubmitHandler = (event) =>{
        let error = ''
        if(formInput.courseName === '' && error === ''){
            error='please enter course name';
            console.log(error);
        }
        console.log(formInput);
        props.onCourseAdded(formInput);
        event.preventDefult();
    }
    return(
        <div className="form-container">
            <h1>Add new courses</h1>
            <form onSubmit={formSubmitHandler}>
                <div className="form-input">
                    <input type="text"placeholder="course name" onChange={courseNameHandler}></input>
                </div>
                <div className="form-input">
                    <input type="text"placeholder="course price" onChange={coursePriceHandler}></input>
                </div>
                <div className="clearfix"></div>
                <div className="form-input">
                    <input type="text"placeholder="course image" onChange={courseImageHandler}></input>
                </div>
                <div className="form-input">
                    <input type="text"placeholder="course conducted by" onChange={courseConductedByHandler}></input>
                </div>
                <div className="clearfix"></div>
                <div className="form-input">
                    <button className="btn_add_course">add course</button>
                </div>
                <div className="clearfix"></div>
            </form>
        </div>
    )
}

export default CourseForm; 
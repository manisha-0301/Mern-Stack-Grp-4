function Product(product_id,product_name,product_price,product_description,product_image){
    this.product_id = product_id;
    this.product_name = product_name;
    this.product_price = product_price;
    this.product_description = product_description;
    this.product_image = product_image;
}

exports.Product = Product; 
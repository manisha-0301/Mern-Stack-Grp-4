import { Product } from './components/product/Product';
import ProductForm from './components/product-form/ProductForm'
import {useState} from 'react';

function App() {
  const [products,setProduct] =useState([
    {
      product_name:"NOISE Jet Black ColorFit Pro 2 Smartwatch",
      product_image:"https://assets.myntassets.com/h_1440,q_90,w_1080/v1/assets/images/10769098/2019/10/17/4e8dc285-fce6-4d57-b058-d79d2132eb271571294516344-NOISE-Black-ColorFit-Pro-2-Active-Smartwatch-324157129451526-1.jpg",
      product_price:"2299",
    },
    {
      product_name:"NOISE ColorFit Qube Oxy Smartwatch - Beige",
      product_image:"https://assets.myntassets.com/h_1440,q_90,w_1080/v1/assets/images/15706182/2021/10/1/a3dd3b4c-db1f-44ec-8349-f109d425a44a1633096764483NOISEUnisexBeigeColorFitQubeOxySmartWatch1.jpg",
      product_price:"1699",
    },
    {
      product_name:"NOISE Fit Evolve 2 Smartwatch - Grey",
      product_image:"https://assets.myntassets.com/h_1440,q_90,w_1080/v1/assets/images/17068204/2022/2/7/9f4fabff-543b-4243-b047-f3759bea3e561644231210957-NOISE-Fit-Evolve-2-Smartwatch---Grey-6551644231210835-3.jpg",
      product_price:"3299",
    }
  ]);
  const addNewProductHandler=(product)=>{
    const productObj = {
      product_name:product.productName,
      product_price:product.productPrice,
      product_image:product.productImage
    }
    setProduct([...products,productObj]);
  }
  return (
    <div className="App">

      <ProductForm onProductAdded ={addNewProductHandler}/>
      <h1>Products List</h1>
      {products.map((product,index) =>
      <Product key = {index} pname = {product.product_name} 
      pimage = {product.product_image} 
      pprice = {'Rs. '+product.product_price}/>
    )}
    </div>
  )
}
export default App;